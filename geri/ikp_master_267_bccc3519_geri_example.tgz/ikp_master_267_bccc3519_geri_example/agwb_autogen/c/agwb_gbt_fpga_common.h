#ifndef __gbt_fpga_common__INC_H
#define __gbt_fpga_common__INC_H
const uint32_t agwb_gbt_fpga_common_ID_VAL = 0xbc250cf2;
const uint32_t agwb_gbt_fpga_common_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_gbt_fpga_common_ctrl_rst_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_rst_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_rst_tx_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_rst_tx_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_rst_rx_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_rst_rx_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_tx_pol_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_tx_pol_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_rx_pol_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_rx_pol_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffef) | ((val & 0x1) << 0x4);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_loopback_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x5) & 0x7;
};
static inline void agwb_gbt_fpga_common_ctrl_loopback_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff1f) | ((val & 0x7) << 0x5);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_loopback_gearbox_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_loopback_gearbox_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffeff) | ((val & 0x1) << 0x8);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_rx_scrambler_bypass_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x9) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_rx_scrambler_bypass_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffdff) | ((val & 0x1) << 0x9);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_tx_scrambler_bypass_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xa) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_tx_scrambler_bypass_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffbff) | ((val & 0x1) << 0xa);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_tx_encoding_sel_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xb) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_tx_encoding_sel_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffff7ff) | ((val & 0x1) << 0xb);
};
static inline uint32_t agwb_gbt_fpga_common_ctrl_rx_encoding_sel_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xc) & 0x1;
};
static inline void agwb_gbt_fpga_common_ctrl_rx_encoding_sel_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffefff) | ((val & 0x1) << 0xc);
};
static inline uint32_t agwb_gbt_fpga_common_patgen_mode_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x3;
};
static inline void agwb_gbt_fpga_common_patgen_mode_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffc) | ((val & 0x3) << 0x0);
};
static inline uint32_t agwb_gbt_fpga_common_patgen_const_dat_patt_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0xff;
};
static inline void agwb_gbt_fpga_common_patgen_const_dat_patt_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffc03) | ((val & 0xff) << 0x2);
};
static inline uint32_t agwb_gbt_fpga_common_patgen_const_wbdat_patt_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xa) & 0xff;
};
static inline void agwb_gbt_fpga_common_patgen_const_wbdat_patt_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffc03ff) | ((val & 0xff) << 0xa);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t ctrl;
  volatile uint32_t patgen;
} __attribute__((aligned(4))) agwb_gbt_fpga_common ;
#endif
