#ifndef __hctsp_master__INC_H
#define __hctsp_master__INC_H
const uint32_t agwb_hctsp_master_ID_VAL = 0x4f37fce9;
const uint32_t agwb_hctsp_master_VER_VAL = 0x7e204a29;
#include <agwb_hctsp_software_command_slot.h>
#include <agwb_hctsp_time_command_slot.h>
#include <agwb_hctsp_time_command_slot.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t fetched_count;
  volatile uint32_t command_cycle_timestamp_0;
  volatile uint32_t command_cycle_timestamp_1;
  volatile uint32_t command_cycle_pause_width;
  volatile uint32_t encoding_modes[36];
  volatile uint32_t filler1[38];
  agwb_hctsp_software_command_slot software_command_slot;
  agwb_hctsp_time_command_slot special_time_command_slot;
  agwb_hctsp_time_command_slot time_command_slots[4];
} __attribute__((aligned(4))) agwb_hctsp_master ;
#endif
