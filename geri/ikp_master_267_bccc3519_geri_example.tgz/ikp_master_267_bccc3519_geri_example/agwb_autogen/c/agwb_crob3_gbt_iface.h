#ifndef __crob3_gbt_iface__INC_H
#define __crob3_gbt_iface__INC_H
const uint32_t agwb_crob3_gbt_iface_ID_VAL = 0x64ade247;
const uint32_t agwb_crob3_gbt_iface_VER_VAL = 0x7e204a29;
#include <agwb_gbt_fpga_common.h>
#include <agwb_gbt_fpga_link.h>
#include <agwb_gbt_sc.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t filler1[10];
  agwb_gbt_fpga_common common;
  agwb_gbt_fpga_link link[3];
  volatile uint32_t filler2[4];
  agwb_gbt_sc gbt_sc;
} __attribute__((aligned(4))) agwb_crob3_gbt_iface ;
#endif
