#ifndef __gbt_ec_ctrl__INC_H
#define __gbt_ec_ctrl__INC_H
const uint32_t agwb_gbt_ec_ctrl_ID_VAL = 0x28f87d63;
const uint32_t agwb_gbt_ec_ctrl_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_gbt_ec_ctrl_ctrl_start_reset_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_gbt_ec_ctrl_ctrl_start_reset_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_gbt_ec_ctrl_ctrl_start_connect_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_gbt_ec_ctrl_ctrl_start_connect_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_gbt_ec_ctrl_ctrl_start_cmd_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_gbt_ec_ctrl_ctrl_start_cmd_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_gbt_ec_ctrl_ctrl_inject_crc_error_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_gbt_ec_ctrl_ctrl_inject_crc_error_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_gbt_ec_ctrl_tx_cmd_command_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_tx_cmd_command_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff00) | ((val & 0xff) << 0x0);
};
static inline uint32_t agwb_gbt_ec_ctrl_tx_cmd_addr_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_tx_cmd_addr_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff00ff) | ((val & 0xff) << 0x8);
};
static inline uint32_t agwb_gbt_ec_ctrl_tx_cmd_chan_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_tx_cmd_chan_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xff00ffff) | ((val & 0xff) << 0x10);
};
static inline uint32_t agwb_gbt_ec_ctrl_tx_cmd_trans_id_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x18) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_tx_cmd_trans_id_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff) | ((val & 0xff) << 0x18);
};
static inline uint32_t agwb_gbt_ec_ctrl_status_received_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_gbt_ec_ctrl_status_received_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_gbt_ec_ctrl_status_len_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_status_len_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffe01) | ((val & 0xff) << 0x1);
};
static inline uint32_t agwb_gbt_ec_ctrl_status_error_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x9) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_status_error_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffe01ff) | ((val & 0xff) << 0x9);
};
static inline uint32_t agwb_gbt_ec_ctrl_status2_control_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_status2_control_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff00) | ((val & 0xff) << 0x0);
};
static inline uint32_t agwb_gbt_ec_ctrl_status2_addr_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_status2_addr_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff00ff) | ((val & 0xff) << 0x8);
};
static inline uint32_t agwb_gbt_ec_ctrl_status2_chan_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_status2_chan_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xff00ffff) | ((val & 0xff) << 0x10);
};
static inline uint32_t agwb_gbt_ec_ctrl_status2_trans_id_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x18) & 0xff;
};
static inline void agwb_gbt_ec_ctrl_status2_trans_id_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff) | ((val & 0xff) << 0x18);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t ctrl;
  volatile uint32_t tx_cmd;
  volatile uint32_t tx_data;
  volatile uint32_t status;
  volatile uint32_t status2;
  volatile uint32_t rx_data;
} __attribute__((aligned(4))) agwb_gbt_ec_ctrl ;
#endif
