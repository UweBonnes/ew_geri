#ifndef __i2c_master__INC_H
#define __i2c_master__INC_H
typedef struct {
  volatile uint32_t filler[32];
}  __attribute__((packed)) agwb_i2c_master;
#endif
