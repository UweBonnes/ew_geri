#ifndef __datapath__INC_H
#define __datapath__INC_H
const uint32_t agwb_datapath_ID_VAL = 0x2b37340;
const uint32_t agwb_datapath_VER_VAL = 0x7e204a29;
#include <agwb_crob3_gbt_iface.h>
#include <agwb_trivial_proc.h>
#include <agwb_tfc.h>
#include <agwb_hctsp_master.h>
#include <agwb_crob1_gbt_iface.h>
#include <agwb_hctsp_uplink.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t filler1[3432];
  agwb_crob3_gbt_iface gbt_fpga_dummy[0];
  volatile uint32_t filler2[2];
  agwb_trivial_proc triv_proc;
  agwb_tfc tfc;
  agwb_hctsp_master hctsp_master_80;
  agwb_crob1_gbt_iface crob1_gbt_iface[6];
  volatile uint32_t filler3[128];
  agwb_hctsp_uplink hctsp_uplink_80[6];
  volatile uint32_t filler4[1024];
} __attribute__((aligned(4))) agwb_datapath ;
#endif
