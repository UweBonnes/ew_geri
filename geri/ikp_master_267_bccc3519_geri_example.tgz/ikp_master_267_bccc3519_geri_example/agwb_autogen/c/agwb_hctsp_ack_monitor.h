#ifndef __hctsp_ack_monitor__INC_H
#define __hctsp_ack_monitor__INC_H
const uint32_t agwb_hctsp_ack_monitor_ID_VAL = 0x27650e93;
const uint32_t agwb_hctsp_ack_monitor_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_hctsp_ack_monitor_frame_missed_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_hctsp_ack_monitor_frame_missed_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_hctsp_ack_monitor_frame_uplink_number_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x3f;
};
static inline void agwb_hctsp_ack_monitor_frame_uplink_number_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff81) | ((val & 0x3f) << 0x1);
};
static inline uint32_t agwb_hctsp_ack_monitor_frame_valid_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x7) & 0x1;
};
static inline void agwb_hctsp_ack_monitor_frame_valid_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff7f) | ((val & 0x1) << 0x7);
};
static inline uint32_t agwb_hctsp_ack_monitor_frame_frame_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0xffffff;
};
static inline void agwb_hctsp_ack_monitor_frame_frame_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xff) | ((val & 0xffffff) << 0x8);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t frame;
  volatile uint32_t clear_detected[2];
  volatile uint32_t detected_0[2];
  volatile uint32_t detected_1[2];
  volatile uint32_t filler1[7];
} __attribute__((aligned(4))) agwb_hctsp_ack_monitor ;
#endif
