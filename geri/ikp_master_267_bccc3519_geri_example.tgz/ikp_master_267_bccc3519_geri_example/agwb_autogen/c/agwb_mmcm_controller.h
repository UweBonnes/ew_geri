#ifndef __mmcm_controller__INC_H
#define __mmcm_controller__INC_H
const uint32_t agwb_mmcm_controller_ID_VAL = 0x133e3702;
const uint32_t agwb_mmcm_controller_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_mmcm_controller_ctrl_ticks_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xfff;
};
static inline void agwb_mmcm_controller_ctrl_ticks_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffff000) | ((val & 0xfff) << 0x0);
};
static inline uint32_t agwb_mmcm_controller_ctrl_incdec_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xc) & 0x1;
};
static inline void agwb_mmcm_controller_ctrl_incdec_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffefff) | ((val & 0x1) << 0xc);
};
static inline uint32_t agwb_mmcm_controller_ctrl_start_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xd) & 0x1;
};
static inline void agwb_mmcm_controller_ctrl_start_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffdfff) | ((val & 0x1) << 0xd);
};
static inline uint32_t agwb_mmcm_controller_ctrl_rst_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xe) & 0x1;
};
static inline void agwb_mmcm_controller_ctrl_rst_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffbfff) | ((val & 0x1) << 0xe);
};
static inline uint32_t agwb_mmcm_controller_ctrl_mmcm_reset_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xf) & 0x1;
};
static inline void agwb_mmcm_controller_ctrl_mmcm_reset_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff7fff) | ((val & 0x1) << 0xf);
};
static inline uint32_t agwb_mmcm_controller_ctrl_refclk_source_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0x1;
};
static inline void agwb_mmcm_controller_ctrl_refclk_source_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffeffff) | ((val & 0x1) << 0x10);
};
static inline uint32_t agwb_mmcm_controller_stat_ticks_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xfff;
};
static inline void agwb_mmcm_controller_stat_ticks_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffff000) | ((val & 0xfff) << 0x0);
};
static inline uint32_t agwb_mmcm_controller_stat_busy_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xc) & 0x1;
};
static inline void agwb_mmcm_controller_stat_busy_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffefff) | ((val & 0x1) << 0xc);
};
static inline uint32_t agwb_mmcm_controller_stat_mmc_locked_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xd) & 0x1;
};
static inline void agwb_mmcm_controller_stat_mmc_locked_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffdfff) | ((val & 0x1) << 0xd);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t ctrl;
  volatile uint32_t stat;
} __attribute__((aligned(4))) agwb_mmcm_controller ;
#endif
