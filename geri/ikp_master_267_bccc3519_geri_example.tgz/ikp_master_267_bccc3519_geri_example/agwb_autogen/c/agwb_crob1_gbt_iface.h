#ifndef __crob1_gbt_iface__INC_H
#define __crob1_gbt_iface__INC_H
const uint32_t agwb_crob1_gbt_iface_ID_VAL = 0x3cc15b86;
const uint32_t agwb_crob1_gbt_iface_VER_VAL = 0x7e204a29;
#include <agwb_gbt_fpga_link.h>
#include <agwb_gbt_fpga_common.h>
#include <agwb_gbt_sc.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t filler1[22];
  agwb_gbt_fpga_link link[1];
  agwb_gbt_fpga_common common;
  agwb_gbt_sc gbt_sc;
} __attribute__((aligned(4))) agwb_crob1_gbt_iface ;
#endif
