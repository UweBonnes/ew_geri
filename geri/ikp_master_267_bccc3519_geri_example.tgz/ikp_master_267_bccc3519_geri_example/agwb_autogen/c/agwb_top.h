#ifndef __top__INC_H
#define __top__INC_H
const uint32_t agwb_top_ID_VAL = 0x1ed91fca;
const uint32_t agwb_top_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_top_geritop_ctrl_i2cmaster_rst_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_top_geritop_ctrl_i2cmaster_rst_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_top_geritop_ctrl_spimaster_rst_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_top_geritop_ctrl_spimaster_rst_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_top_geritop_ctrl_jc_reset_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_top_geritop_ctrl_jc_reset_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_top_geritop_ctrl_jc_sync_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_top_geritop_ctrl_jc_sync_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_top_geritop_ctrl_clk_rec_oe_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0xff;
};
static inline void agwb_top_geritop_ctrl_clk_rec_oe_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffff00f) | ((val & 0xff) << 0x4);
};
static inline uint32_t agwb_top_geritop_ctrl_refclk_av_get(uint32_t * ptr) { 
  return ((* ptr) >> 0xc) & 0x1;
};
static inline void agwb_top_geritop_ctrl_refclk_av_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffefff) | ((val & 0x1) << 0xc);
};
#include <agwb_mmcm_controller.h>
#include <agwb_spi_master.h>
#include <agwb_i2c_master.h>
#include <agwb_datapath.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t clk_ref40_freq;
  volatile uint32_t clk_ref120_freq;
  volatile uint32_t clk_jcosc_freq;
  volatile uint32_t clk_recovered_freq;
  volatile uint32_t clk_recovered_vs_ref_freq;
  volatile uint32_t testreg;
  volatile uint32_t geritop_ctrl;
  volatile uint32_t filler1[8115];
  agwb_mmcm_controller mmcm_controller;
  agwb_spi_master spi_master;
  agwb_i2c_master i2c_master;
  agwb_datapath datapath;
} __attribute__((aligned(4))) agwb_top ;
#endif
