#ifndef __hctsp_time_command_slot__INC_H
#define __hctsp_time_command_slot__INC_H
const uint32_t agwb_hctsp_time_command_slot_ID_VAL = 0x531c39ab;
const uint32_t agwb_hctsp_time_command_slot_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_hctsp_time_command_slot_control_chip_address_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xf;
};
static inline void agwb_hctsp_time_command_slot_control_chip_address_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff0) | ((val & 0xf) << 0x0);
};
static inline uint32_t agwb_hctsp_time_command_slot_control_downlink_mask_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0xfff;
};
static inline void agwb_hctsp_time_command_slot_control_downlink_mask_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff000f) | ((val & 0xfff) << 0x4);
};
static inline uint32_t agwb_hctsp_time_command_slot_control_group_mask_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0xff;
};
static inline void agwb_hctsp_time_command_slot_control_group_mask_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xff00ffff) | ((val & 0xff) << 0x10);
};
static inline uint32_t agwb_hctsp_time_command_slot_control_sequence_number_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x18) & 0xf;
};
static inline void agwb_hctsp_time_command_slot_control_sequence_number_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xf0ffffff) | ((val & 0xf) << 0x18);
};
static inline uint32_t agwb_hctsp_time_command_slot_control_frame_request_type_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x3;
};
static inline void agwb_hctsp_time_command_slot_control_frame_request_type_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffc) | ((val & 0x3) << 0x0);
};
static inline uint32_t agwb_hctsp_time_command_slot_control_frame_request_payload_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x7fff;
};
static inline void agwb_hctsp_time_command_slot_control_frame_request_payload_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffe0003) | ((val & 0x7fff) << 0x2);
};
static inline uint32_t agwb_hctsp_time_command_slot_control_frame_crc_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x11) & 0x7fff;
};
static inline void agwb_hctsp_time_command_slot_control_frame_crc_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0x1ffff) | ((val & 0x7fff) << 0x11);
};
static inline uint32_t agwb_hctsp_time_command_slot_status_armed_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_hctsp_time_command_slot_status_armed_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_hctsp_time_command_slot_status_armed_in_past_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_hctsp_time_command_slot_status_armed_in_past_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t control;
  volatile uint32_t control_frame[2];
  volatile uint32_t timestamp;
  volatile uint32_t period;
  volatile uint32_t status;
} __attribute__((aligned(4))) agwb_hctsp_time_command_slot ;
#endif
