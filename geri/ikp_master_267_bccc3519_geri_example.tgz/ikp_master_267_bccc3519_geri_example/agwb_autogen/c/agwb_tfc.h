#ifndef __tfc__INC_H
#define __tfc__INC_H
const uint32_t agwb_tfc_ID_VAL = 0x4ba5e55d;
const uint32_t agwb_tfc_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_tfc_ctrl_sync_time_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_tfc_ctrl_sync_time_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
#include <agwb_gbt_fpga_link.h>
#include <agwb_gbt_fpga_common.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t ctrl;
  volatile uint32_t filler1[5];
  agwb_gbt_fpga_link link;
  agwb_gbt_fpga_common common;
} __attribute__((aligned(4))) agwb_tfc ;
#endif
