#ifndef __hctsp_receiver__INC_H
#define __hctsp_receiver__INC_H
const uint32_t agwb_hctsp_receiver_ID_VAL = 0x9eb288f1;
const uint32_t agwb_hctsp_receiver_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_sos_detected_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_sos_detected_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_sos_stable0_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_sos_stable0_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_sos_stable1_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_sos_stable1_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_k28_1_detected_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_k28_1_detected_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_k28_1_stable1_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_k28_1_stable1_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffef) | ((val & 0x1) << 0x4);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_eos_detected_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x5) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_eos_detected_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffdf) | ((val & 0x1) << 0x5);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_eos_stable1_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x6) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_eos_stable1_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffbf) | ((val & 0x1) << 0x6);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_k28_5_detected_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x7) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_k28_5_detected_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff7f) | ((val & 0x1) << 0x7);
};
static inline uint32_t agwb_hctsp_receiver_sequence_detectors_status_k28_5_stable1_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0x1;
};
static inline void agwb_hctsp_receiver_sequence_detectors_status_k28_5_stable1_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffeff) | ((val & 0x1) << 0x8);
};
static inline uint32_t agwb_hctsp_receiver_errors_bitslip_change_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_bitslip_change_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_hctsp_receiver_errors_code_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_code_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_hctsp_receiver_errors_disparity_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_disparity_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_hctsp_receiver_errors_decoding_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_decoding_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_hctsp_receiver_errors_frame_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_frame_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffef) | ((val & 0x1) << 0x4);
};
static inline uint32_t agwb_hctsp_receiver_errors_heart_beat_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x5) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_heart_beat_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffdf) | ((val & 0x1) << 0x5);
};
static inline uint32_t agwb_hctsp_receiver_errors_clear_mask_bitslip_change_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_clear_mask_bitslip_change_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_hctsp_receiver_errors_clear_mask_code_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_clear_mask_code_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_hctsp_receiver_errors_clear_mask_disparity_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_clear_mask_disparity_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_hctsp_receiver_errors_clear_mask_decoding_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_clear_mask_decoding_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_hctsp_receiver_errors_clear_mask_frame_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_clear_mask_frame_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffef) | ((val & 0x1) << 0x4);
};
static inline uint32_t agwb_hctsp_receiver_errors_clear_mask_heart_beat_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x5) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_clear_mask_heart_beat_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffdf) | ((val & 0x1) << 0x5);
};
static inline uint32_t agwb_hctsp_receiver_errors_alarm_mask_bitslip_change_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_alarm_mask_bitslip_change_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_hctsp_receiver_errors_alarm_mask_code_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_alarm_mask_code_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_hctsp_receiver_errors_alarm_mask_disparity_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_alarm_mask_disparity_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_hctsp_receiver_errors_alarm_mask_decoding_8b10b_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_alarm_mask_decoding_8b10b_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_hctsp_receiver_errors_alarm_mask_frame_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_alarm_mask_frame_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffef) | ((val & 0x1) << 0x4);
};
static inline uint32_t agwb_hctsp_receiver_errors_alarm_mask_heart_beat_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x5) & 0x1;
};
static inline void agwb_hctsp_receiver_errors_alarm_mask_heart_beat_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffdf) | ((val & 0x1) << 0x5);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t clear_sequence_detectors;
  volatile uint32_t sequence_detectors_status;
  volatile uint32_t errors;
  volatile uint32_t errors_clear_mask;
  volatile uint32_t errors_alarm_mask;
  volatile uint32_t filler1[1];
} __attribute__((aligned(4))) agwb_hctsp_receiver ;
#endif
