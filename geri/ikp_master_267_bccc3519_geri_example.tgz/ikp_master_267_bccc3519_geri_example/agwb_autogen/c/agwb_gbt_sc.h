#ifndef __gbt_sc__INC_H
#define __gbt_sc__INC_H
const uint32_t agwb_gbt_sc_ID_VAL = 0x14d5fefd;
const uint32_t agwb_gbt_sc_VER_VAL = 0x7e204a29;
#include <agwb_gbt_ec_ctrl.h>
#include <agwb_gbt_ic_ctrl.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t filler1[14];
  agwb_gbt_ec_ctrl ec;
  agwb_gbt_ic_ctrl ic;
} __attribute__((aligned(4))) agwb_gbt_sc ;
#endif
