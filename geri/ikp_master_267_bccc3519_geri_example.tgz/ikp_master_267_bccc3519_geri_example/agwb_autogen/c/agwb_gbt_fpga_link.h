#ifndef __gbt_fpga_link__INC_H
#define __gbt_fpga_link__INC_H
const uint32_t agwb_gbt_fpga_link_ID_VAL = 0x1d424d7a;
const uint32_t agwb_gbt_fpga_link_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_gbt_fpga_link_status_link_ready_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_link_ready_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_gbt_fpga_link_status_rx_ready_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_rx_ready_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_gbt_fpga_link_status_rx_headerflag_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_rx_headerflag_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_gbt_fpga_link_status_rx_header_locked_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_rx_header_locked_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffff7) | ((val & 0x1) << 0x3);
};
static inline uint32_t agwb_gbt_fpga_link_status_tx_ready_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x4) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_tx_ready_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffef) | ((val & 0x1) << 0x4);
};
static inline uint32_t agwb_gbt_fpga_link_status_tx_phaligned_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x5) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_tx_phaligned_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffdf) | ((val & 0x1) << 0x5);
};
static inline uint32_t agwb_gbt_fpga_link_status_tx_phaligned_val_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x6) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_tx_phaligned_val_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffffbf) | ((val & 0x1) << 0x6);
};
static inline uint32_t agwb_gbt_fpga_link_status_rx_bufferbypas_error_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x7) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_rx_bufferbypas_error_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff7f) | ((val & 0x1) << 0x7);
};
static inline uint32_t agwb_gbt_fpga_link_status_tx_bufferbypas_error_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_tx_bufferbypas_error_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffeff) | ((val & 0x1) << 0x8);
};
static inline uint32_t agwb_gbt_fpga_link_status_rx_ic_inactive_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x9) & 0x1;
};
static inline void agwb_gbt_fpga_link_status_rx_ic_inactive_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffdff) | ((val & 0x1) << 0x9);
};
static inline uint32_t agwb_gbt_fpga_link_status_with_clear_rx_error_cnt_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xff;
};
static inline void agwb_gbt_fpga_link_status_with_clear_rx_error_cnt_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffffff00) | ((val & 0xff) << 0x0);
};
static inline uint32_t agwb_gbt_fpga_link_status_with_clear_rx_readyloss_cnt_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x8) & 0xff;
};
static inline void agwb_gbt_fpga_link_status_with_clear_rx_readyloss_cnt_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff00ff) | ((val & 0xff) << 0x8);
};
static inline uint32_t agwb_gbt_fpga_link_status_with_clear_rx_pattcheck_errcnt_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0xffff;
};
static inline void agwb_gbt_fpga_link_status_with_clear_rx_pattcheck_errcnt_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff) | ((val & 0xffff) << 0x10);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t status;
  volatile uint32_t status_with_clear;
} __attribute__((aligned(4))) agwb_gbt_fpga_link ;
#endif
