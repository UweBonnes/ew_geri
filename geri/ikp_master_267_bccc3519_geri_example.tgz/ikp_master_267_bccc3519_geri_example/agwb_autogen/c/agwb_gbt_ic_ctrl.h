#ifndef __gbt_ic_ctrl__INC_H
#define __gbt_ic_ctrl__INC_H
const uint32_t agwb_gbt_ic_ctrl_ID_VAL = 0xef581717;
const uint32_t agwb_gbt_ic_ctrl_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_gbt_ic_ctrl_ctrl_reset_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_gbt_ic_ctrl_ctrl_reset_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_gbt_ic_ctrl_ctrl_start_write_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_gbt_ic_ctrl_ctrl_start_write_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_gbt_ic_ctrl_ctrl_start_read_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x1;
};
static inline void agwb_gbt_ic_ctrl_ctrl_start_read_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffb) | ((val & 0x1) << 0x2);
};
static inline uint32_t agwb_gbt_ic_ctrl_ctrl_gbtx_addr_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x3) & 0x7f;
};
static inline void agwb_gbt_ic_ctrl_ctrl_gbtx_addr_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffc07) | ((val & 0x7f) << 0x3);
};
static inline uint32_t agwb_gbt_ic_ctrl_tx_rega_nbtr_reg_addr_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xffff;
};
static inline void agwb_gbt_ic_ctrl_tx_rega_nbtr_reg_addr_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff0000) | ((val & 0xffff) << 0x0);
};
static inline uint32_t agwb_gbt_ic_ctrl_tx_rega_nbtr_bytes_to_read_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0xffff;
};
static inline void agwb_gbt_ic_ctrl_tx_rega_nbtr_bytes_to_read_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff) | ((val & 0xffff) << 0x10);
};
static inline uint32_t agwb_gbt_ic_ctrl_status_tx_ready_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_gbt_ic_ctrl_status_tx_ready_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_gbt_ic_ctrl_status_rx_empty_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_gbt_ic_ctrl_status_rx_empty_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_gbt_ic_ctrl_status_gbtx_addr_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0x7f;
};
static inline void agwb_gbt_ic_ctrl_status_gbtx_addr_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffe03) | ((val & 0x7f) << 0x2);
};
static inline uint32_t agwb_gbt_ic_ctrl_rx_mptr_nbw_mem_ptr_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0xffff;
};
static inline void agwb_gbt_ic_ctrl_rx_mptr_nbw_mem_ptr_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff0000) | ((val & 0xffff) << 0x0);
};
static inline uint32_t agwb_gbt_ic_ctrl_rx_mptr_nbw_words_read_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x10) & 0xffff;
};
static inline void agwb_gbt_ic_ctrl_rx_mptr_nbw_words_read_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xffff) | ((val & 0xffff) << 0x10);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t ctrl;
  volatile uint32_t tx_rega_nbtr;
  volatile uint32_t tx_data;
  volatile uint32_t status;
  volatile uint32_t rx_mptr_nbw;
  volatile uint32_t rx_data;
} __attribute__((aligned(4))) agwb_gbt_ic_ctrl ;
#endif
