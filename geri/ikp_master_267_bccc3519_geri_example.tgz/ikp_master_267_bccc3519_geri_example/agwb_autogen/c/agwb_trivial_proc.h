#ifndef __trivial_proc__INC_H
#define __trivial_proc__INC_H
const uint32_t agwb_trivial_proc_ID_VAL = 0x791832e1;
const uint32_t agwb_trivial_proc_VER_VAL = 0x7e204a29;
static inline uint32_t agwb_trivial_proc_ctrl_reset_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x0) & 0x1;
};
static inline void agwb_trivial_proc_ctrl_reset_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffe) | ((val & 0x1) << 0x0);
};
static inline uint32_t agwb_trivial_proc_ctrl_run_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x1) & 0x1;
};
static inline void agwb_trivial_proc_ctrl_run_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffffd) | ((val & 0x1) << 0x1);
};
static inline uint32_t agwb_trivial_proc_ctrl_crob_disable_get(uint32_t * ptr) { 
  return ((* ptr) >> 0x2) & 0xff;
};
static inline void agwb_trivial_proc_ctrl_crob_disable_set(uint32_t * ptr, uint32_t val) { 
  * ptr = ((* ptr) & 0xfffffc03) | ((val & 0xff) << 0x2);
};
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t ctrl;
  volatile uint32_t pkt_duration;
} __attribute__((aligned(4))) agwb_trivial_proc ;
#endif
