#ifndef _agwb_top_inc_H_
#define _agwb_top_inc_H_

#define NR_CROB1 6 // 6
#define N_HCTSP_GROUPS 6 // NR_CROB1
#define N_HCTSP_DOWNLINKS 6 // 6
#define N_HCTSP_UPLINKS 28 // 28

#endif
