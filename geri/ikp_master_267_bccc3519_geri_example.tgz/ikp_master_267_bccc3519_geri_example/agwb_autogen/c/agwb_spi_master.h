#ifndef __spi_master__INC_H
#define __spi_master__INC_H
typedef struct {
  volatile uint32_t filler[32];
}  __attribute__((packed)) agwb_spi_master;
#endif
