#ifndef __hctsp_uplink__INC_H
#define __hctsp_uplink__INC_H
const uint32_t agwb_hctsp_uplink_ID_VAL = 0x6629c4cc;
const uint32_t agwb_hctsp_uplink_VER_VAL = 0x7e204a29;
#include <agwb_hctsp_ack_monitor.h>
#include <agwb_hctsp_receiver.h>
typedef struct {
  volatile uint32_t ID;
  volatile uint32_t VER;
  volatile uint32_t uplinks_mask_0;
  volatile uint32_t uplinks_mask_1;
  volatile uint32_t strict_mode_0;
  volatile uint32_t strict_mode_1;
  volatile uint32_t filler1[234];
  agwb_hctsp_ack_monitor ack_monitor;
  agwb_hctsp_receiver receivers[28];
  volatile uint32_t filler2[32];
} __attribute__((aligned(4))) agwb_hctsp_uplink ;
#endif
