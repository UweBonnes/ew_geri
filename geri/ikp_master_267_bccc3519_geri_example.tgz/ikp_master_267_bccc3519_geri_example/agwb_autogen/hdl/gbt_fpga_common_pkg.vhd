--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package gbt_fpga_common_pkg is

  constant C_gbt_fpga_common_ADDR_BITS : integer := 2;

  constant c_gbt_fpga_common_ver_id : std_logic_vector(31 downto 0) := x"e5e44e32";
  constant v_gbt_fpga_common_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"e5e44e32");
  constant c_ctrl_size : integer := 1;
  constant c_patgen_size : integer := 1;


  constant C_ctrl_REG_ADDR: unsigned := x"00000002";
  type t_ctrl is record
    rst:std_logic_vector(0 downto 0);
    rst_tx:std_logic_vector(0 downto 0);
    rst_rx:std_logic_vector(0 downto 0);
    tx_pol:std_logic_vector(0 downto 0);
    rx_pol:std_logic_vector(0 downto 0);
    loopback:std_logic_vector(2 downto 0);
    loopback_gearbox:std_logic_vector(0 downto 0);
    rx_scrambler_bypass:std_logic_vector(0 downto 0);
    tx_scrambler_bypass:std_logic_vector(0 downto 0);
    tx_encoding_sel:std_logic_vector(0 downto 0);
    rx_encoding_sel:std_logic_vector(0 downto 0);
  end record;
  
  function to_ctrl(x : std_logic_vector) return t_ctrl;
  function to_slv(x : t_ctrl) return std_logic_vector;
  constant C_patgen_REG_ADDR: unsigned := x"00000003";
  type t_patgen is record
    mode:std_logic_vector(1 downto 0);
    const_dat_patt:std_logic_vector(7 downto 0);
    const_wbdat_patt:std_logic_vector(7 downto 0);
  end record;
  
  function to_patgen(x : std_logic_vector) return t_patgen;
  function to_slv(x : t_patgen) return std_logic_vector;




end gbt_fpga_common_pkg;

package body gbt_fpga_common_pkg is
  function to_ctrl(x : std_logic_vector) return t_ctrl is
    variable res : t_ctrl;
  begin
    res.rst := std_logic_vector(x(0 downto 0));
    res.rst_tx := std_logic_vector(x(1 downto 1));
    res.rst_rx := std_logic_vector(x(2 downto 2));
    res.tx_pol := std_logic_vector(x(3 downto 3));
    res.rx_pol := std_logic_vector(x(4 downto 4));
    res.loopback := std_logic_vector(x(7 downto 5));
    res.loopback_gearbox := std_logic_vector(x(8 downto 8));
    res.rx_scrambler_bypass := std_logic_vector(x(9 downto 9));
    res.tx_scrambler_bypass := std_logic_vector(x(10 downto 10));
    res.tx_encoding_sel := std_logic_vector(x(11 downto 11));
    res.rx_encoding_sel := std_logic_vector(x(12 downto 12));
    return res;
  end function;
  
  function to_slv(x : t_ctrl) return std_logic_vector is
    variable res : std_logic_vector(12 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.rst);
    res(1 downto 1) := std_logic_vector(x.rst_tx);
    res(2 downto 2) := std_logic_vector(x.rst_rx);
    res(3 downto 3) := std_logic_vector(x.tx_pol);
    res(4 downto 4) := std_logic_vector(x.rx_pol);
    res(7 downto 5) := std_logic_vector(x.loopback);
    res(8 downto 8) := std_logic_vector(x.loopback_gearbox);
    res(9 downto 9) := std_logic_vector(x.rx_scrambler_bypass);
    res(10 downto 10) := std_logic_vector(x.tx_scrambler_bypass);
    res(11 downto 11) := std_logic_vector(x.tx_encoding_sel);
    res(12 downto 12) := std_logic_vector(x.rx_encoding_sel);
    return res;
  end function;
  
  function to_patgen(x : std_logic_vector) return t_patgen is
    variable res : t_patgen;
  begin
    res.mode := std_logic_vector(x(1 downto 0));
    res.const_dat_patt := std_logic_vector(x(9 downto 2));
    res.const_wbdat_patt := std_logic_vector(x(17 downto 10));
    return res;
  end function;
  
  function to_slv(x : t_patgen) return std_logic_vector is
    variable res : std_logic_vector(17 downto 0);
  begin
    res(1 downto 0) := std_logic_vector(x.mode);
    res(9 downto 2) := std_logic_vector(x.const_dat_patt);
    res(17 downto 10) := std_logic_vector(x.const_wbdat_patt);
    return res;
  end function;
  

end gbt_fpga_common_pkg;
