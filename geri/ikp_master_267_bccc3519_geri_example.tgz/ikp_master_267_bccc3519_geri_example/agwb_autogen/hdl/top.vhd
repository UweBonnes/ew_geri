--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library general_cores;
use general_cores.wishbone_pkg.all;
library work;
use work.agwb_pkg.all;
use work.top_pkg.all;

entity top is
  generic (
    g_clk_ref40_freq_size : integer := c_clk_ref40_freq_size;
    g_clk_ref120_freq_size : integer := c_clk_ref120_freq_size;
    g_clk_jcosc_freq_size : integer := c_clk_jcosc_freq_size;
    g_clk_recovered_freq_size : integer := c_clk_recovered_freq_size;
    g_clk_recovered_vs_ref_freq_size : integer := c_clk_recovered_vs_ref_freq_size;
    g_testreg_size : integer := c_testreg_size;
    g_geritop_ctrl_size : integer := c_geritop_ctrl_size;
    g_datapath_size : integer := c_datapath_size;
    g_i2c_master_size : integer := c_i2c_master_size;
    g_spi_master_size : integer := c_spi_master_size;
    g_mmcm_controller_size : integer := c_mmcm_controller_size;

    g_ver_id : std_logic_vector(31 downto 0) := c_top_ver_id;
    g_registered : integer := 0
  );
  port (
    slave_i : in t_wishbone_slave_in;
    slave_o : out t_wishbone_slave_out;
    datapath_wb_m_o : out t_wishbone_master_out;
    datapath_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    i2c_master_wb_m_o : out t_wishbone_master_out;
    i2c_master_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    spi_master_wb_m_o : out t_wishbone_master_out;
    spi_master_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    mmcm_controller_wb_m_o : out t_wishbone_master_out;
    mmcm_controller_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;

    clk_ref40_freq_i : in  t_clk_ref40_freq;
    clk_ref120_freq_i : in  t_clk_ref120_freq;
    clk_jcosc_freq_i : in  t_clk_jcosc_freq;
    clk_recovered_freq_i : in  t_clk_recovered_freq;
    clk_recovered_vs_ref_freq_i : in  t_clk_recovered_vs_ref_freq;
    testreg_o : out  t_testreg;
    geritop_ctrl_o : out  t_geritop_ctrl;

    rst_n_i : in std_logic;
    clk_sys_i : in std_logic
    );

end top;

architecture gener of top is
  signal int_testreg_o : t_testreg;
  signal int_geritop_ctrl_o : t_geritop_ctrl := to_geritop_ctrl(std_logic_vector(to_unsigned(0,13))); -- Hex value: 0x0


  -- Internal WB declaration
  signal int_regs_wb_m_o : t_wishbone_master_out;
  signal int_regs_wb_m_i : t_wishbone_master_in;
  signal int_addr : std_logic_vector(4-1 downto 0);
  signal wb_up_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_up_r_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_r_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_m_o : t_wishbone_master_out_array(5-1 downto 0);
  signal wb_m_i : t_wishbone_master_in_array(5-1 downto 0) := (others => c_WB_SLAVE_OUT_ERR);

  -- Constants
  constant c_address : t_wishbone_address_array(5-1  downto 0) := (0=>"00000000000000000010000000000000",1=>"00000000000000000001111111100000",2=>"00000000000000000001111111000000",3=>"00000000000000000000000000000000",4=>"00000000000000000001111110111100");
  constant c_mask : t_wishbone_address_array(5-1 downto 0) := (0=>"00000000000000000010000000000000",1=>"00000000000000000011111111100000",2=>"00000000000000000011111111100000",3=>"00000000000000000011111111110000",4=>"00000000000000000011111111111100");
begin
  
  assert g_clk_ref40_freq_size <= c_clk_ref40_freq_size report "g_clk_ref40_freq_size must be not greater than c_clk_ref40_freq_size=1" severity failure;
  assert g_clk_ref120_freq_size <= c_clk_ref120_freq_size report "g_clk_ref120_freq_size must be not greater than c_clk_ref120_freq_size=1" severity failure;
  assert g_clk_jcosc_freq_size <= c_clk_jcosc_freq_size report "g_clk_jcosc_freq_size must be not greater than c_clk_jcosc_freq_size=1" severity failure;
  assert g_clk_recovered_freq_size <= c_clk_recovered_freq_size report "g_clk_recovered_freq_size must be not greater than c_clk_recovered_freq_size=1" severity failure;
  assert g_clk_recovered_vs_ref_freq_size <= c_clk_recovered_vs_ref_freq_size report "g_clk_recovered_vs_ref_freq_size must be not greater than c_clk_recovered_vs_ref_freq_size=1" severity failure;
  assert g_testreg_size <= c_testreg_size report "g_testreg_size must be not greater than c_testreg_size=1" severity failure;
  assert g_geritop_ctrl_size <= c_geritop_ctrl_size report "g_geritop_ctrl_size must be not greater than c_geritop_ctrl_size=1" severity failure;
  assert g_datapath_size <= c_datapath_size report "g_datapath_size must be not greater than c_datapath_size=1" severity failure;
  assert g_i2c_master_size <= c_i2c_master_size report "g_i2c_master_size must be not greater than c_i2c_master_size=1" severity failure;
  assert g_spi_master_size <= c_spi_master_size report "g_spi_master_size must be not greater than c_spi_master_size=1" severity failure;
  assert g_mmcm_controller_size <= c_mmcm_controller_size report "g_mmcm_controller_size must be not greater than c_mmcm_controller_size=1" severity failure;

  wb_up_i(0) <= slave_i;
  slave_o <= wb_up_o(0);
  int_addr <= int_regs_wb_m_o.adr(4-1 downto 0);

-- Conditional adding of xwb_register   
  gr1: if g_registered = 2 generate
    grl1: for i in 0 to 1-1 generate
      xwb_register_1: entity general_cores.xwb_register
      generic map (
        g_WB_MODE => CLASSIC)
      port map (
        rst_n_i  => rst_n_i,
        clk_i    => clk_sys_i,
        slave_i  => wb_up_i(i),
        slave_o  => wb_up_o(i),
        master_i => wb_up_r_o(i),
        master_o => wb_up_r_i(i));
    end generate grl1;
  end generate gr1;

  gr2: if g_registered /= 2 generate
      wb_up_r_i <= wb_up_i;
      wb_up_o <= wb_up_r_o;
  end generate gr2;

-- Main crossbar
  xwb_crossbar_1: entity general_cores.xwb_crossbar
  generic map (
     g_num_masters => 1,
     g_num_slaves  => 5,
     g_registered  => (g_registered = 1),
     g_address     => c_address,
     g_mask        => c_mask
  )
  port map (
     clk_sys_i => clk_sys_i,
     rst_n_i   => rst_n_i,
     slave_i   => wb_up_r_i,
     slave_o   => wb_up_r_o,
     master_i  => wb_m_i,
     master_o  => wb_m_o,
     sdb_sel_o => open
  );

-- Process for register access
  process(clk_sys_i)
  begin
    if rising_edge(clk_sys_i) then
      if rst_n_i = '0' then
        -- Reset of the core
        int_regs_wb_m_i <= c_DUMMY_WB_MASTER_IN;
        int_geritop_ctrl_o <= to_geritop_ctrl(std_logic_vector(to_unsigned(0,13))); -- Hex value: 0x0

      else
        -- Clearing of trigger bits (if there are any)

        -- Normal operation
        int_regs_wb_m_i.rty <= '0';
        int_regs_wb_m_i.ack <= '0';
        int_regs_wb_m_i.err <= '0';

        if (int_regs_wb_m_o.cyc = '1') and (int_regs_wb_m_o.stb = '1')
            and (int_regs_wb_m_i.err = '0') and (int_regs_wb_m_i.rty = '0')
            and (int_regs_wb_m_i.ack = '0') then
          int_regs_wb_m_i.err <= '1'; -- in case of missed address
          -- Access, now we handle consecutive registers
          -- Set the error state so it is output when none register is accessed
          int_regs_wb_m_i.dat <= x"A5A5A5A5";
          int_regs_wb_m_i.ack <= '0';
          int_regs_wb_m_i.err <= '1';
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_clk_ref40_freq_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(2 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(31 downto 0) <= std_logic_vector(clk_ref40_freq_i);
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_clk_ref40_freq_size
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_clk_ref120_freq_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(3 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(31 downto 0) <= std_logic_vector(clk_ref120_freq_i);
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_clk_ref120_freq_size
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_clk_jcosc_freq_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(4 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(31 downto 0) <= std_logic_vector(clk_jcosc_freq_i);
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_clk_jcosc_freq_size
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_clk_recovered_freq_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(5 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(31 downto 0) <= std_logic_vector(clk_recovered_freq_i);
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_clk_recovered_freq_size
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_clk_recovered_vs_ref_freq_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(6 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(31 downto 0) <= std_logic_vector(clk_recovered_vs_ref_freq_i);
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_clk_recovered_vs_ref_freq_size
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_testreg_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(7 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(31 downto 0) <= std_logic_vector(int_testreg_o);
              if int_regs_wb_m_o.we = '1' then
                int_testreg_o <= std_logic_vector(int_regs_wb_m_o.dat(31 downto 0));
              end if;
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_testreg_size
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_geritop_ctrl_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(8 + i, 4)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(12 downto 0) <= to_slv(int_geritop_ctrl_o);
              if int_regs_wb_m_o.we = '1' then
                int_geritop_ctrl_o <= to_geritop_ctrl(int_regs_wb_m_o.dat(12 downto 0));
              end if;
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_geritop_ctrl_size


          if int_addr = "0000" then
             int_regs_wb_m_i.dat <= x"1ed91fca";
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
          if int_addr = "0001" then
             int_regs_wb_m_i.dat <= g_ver_id;
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
        end if;
      end if;
    end if;
  end process;
  testreg_o <= int_testreg_o;
  geritop_ctrl_o <= int_geritop_ctrl_o;
  bg1: if g_datapath_size > 0 generate
    wb_m_i(0) <= datapath_wb_m_i;
    datapath_wb_m_o  <= wb_m_o(0);
  end generate; -- g_datapath_size
  bg2: if g_i2c_master_size > 0 generate
    wb_m_i(1) <= i2c_master_wb_m_i;
    i2c_master_wb_m_o  <= wb_m_o(1);
  end generate; -- g_i2c_master_size
  bg3: if g_spi_master_size > 0 generate
    wb_m_i(2) <= spi_master_wb_m_i;
    spi_master_wb_m_o  <= wb_m_o(2);
  end generate; -- g_spi_master_size
  wb_m_i(3) <= int_regs_wb_m_i;
  int_regs_wb_m_o  <= wb_m_o(3);
  bg4: if g_mmcm_controller_size > 0 generate
    wb_m_i(4) <= mmcm_controller_wb_m_i;
    mmcm_controller_wb_m_o  <= wb_m_o(4);
  end generate; -- g_mmcm_controller_size

end architecture;
