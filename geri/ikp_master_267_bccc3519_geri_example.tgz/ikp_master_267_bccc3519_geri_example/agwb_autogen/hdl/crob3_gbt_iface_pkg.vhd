--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package crob3_gbt_iface_pkg is

  constant C_crob3_gbt_iface_ADDR_BITS : integer := 6;

  constant c_crob3_gbt_iface_ver_id : std_logic_vector(31 downto 0) := x"c7b597cc";
  constant v_crob3_gbt_iface_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"c7b597cc");
  constant c_gbt_sc_size : integer := 1;
  constant c_link_size : integer := 3;
  constant c_common_size : integer := 1;






end crob3_gbt_iface_pkg;

package body crob3_gbt_iface_pkg is

end crob3_gbt_iface_pkg;
