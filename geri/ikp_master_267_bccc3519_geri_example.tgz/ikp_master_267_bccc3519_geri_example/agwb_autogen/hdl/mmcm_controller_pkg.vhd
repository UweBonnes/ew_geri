--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package mmcm_controller_pkg is

  constant C_mmcm_controller_ADDR_BITS : integer := 2;

  constant c_mmcm_controller_ver_id : std_logic_vector(31 downto 0) := x"7da6e985";
  constant v_mmcm_controller_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"7da6e985");
  constant c_ctrl_trig_clear : std_logic_vector(16 downto 0) := "11101111111111111";
  constant c_ctrl_size : integer := 1;
  constant c_stat_size : integer := 1;


  constant C_ctrl_REG_ADDR: unsigned := x"00000002";
  type t_ctrl is record
    ticks:std_logic_vector(11 downto 0);
    incdec:std_logic_vector(0 downto 0);
    start:std_logic_vector(0 downto 0);
    rst:std_logic_vector(0 downto 0);
    mmcm_reset:std_logic_vector(0 downto 0);
    refclk_source:std_logic_vector(0 downto 0);
  end record;
  
  function to_ctrl(x : std_logic_vector) return t_ctrl;
  function to_slv(x : t_ctrl) return std_logic_vector;
  constant C_stat_REG_ADDR: unsigned := x"00000003";
  type t_stat is record
    ticks:std_logic_vector(11 downto 0);
    busy:std_logic_vector(0 downto 0);
    mmc_locked:std_logic_vector(0 downto 0);
  end record;
  
  function to_stat(x : std_logic_vector) return t_stat;
  function to_slv(x : t_stat) return std_logic_vector;




end mmcm_controller_pkg;

package body mmcm_controller_pkg is
  function to_ctrl(x : std_logic_vector) return t_ctrl is
    variable res : t_ctrl;
  begin
    res.ticks := std_logic_vector(x(11 downto 0));
    res.incdec := std_logic_vector(x(12 downto 12));
    res.start := std_logic_vector(x(13 downto 13));
    res.rst := std_logic_vector(x(14 downto 14));
    res.mmcm_reset := std_logic_vector(x(15 downto 15));
    res.refclk_source := std_logic_vector(x(16 downto 16));
    return res;
  end function;
  
  function to_slv(x : t_ctrl) return std_logic_vector is
    variable res : std_logic_vector(16 downto 0);
  begin
    res(11 downto 0) := std_logic_vector(x.ticks);
    res(12 downto 12) := std_logic_vector(x.incdec);
    res(13 downto 13) := std_logic_vector(x.start);
    res(14 downto 14) := std_logic_vector(x.rst);
    res(15 downto 15) := std_logic_vector(x.mmcm_reset);
    res(16 downto 16) := std_logic_vector(x.refclk_source);
    return res;
  end function;
  
  function to_stat(x : std_logic_vector) return t_stat is
    variable res : t_stat;
  begin
    res.ticks := std_logic_vector(x(11 downto 0));
    res.busy := std_logic_vector(x(12 downto 12));
    res.mmc_locked := std_logic_vector(x(13 downto 13));
    return res;
  end function;
  
  function to_slv(x : t_stat) return std_logic_vector is
    variable res : std_logic_vector(13 downto 0);
  begin
    res(11 downto 0) := std_logic_vector(x.ticks);
    res(12 downto 12) := std_logic_vector(x.busy);
    res(13 downto 13) := std_logic_vector(x.mmc_locked);
    return res;
  end function;
  

end mmcm_controller_pkg;
