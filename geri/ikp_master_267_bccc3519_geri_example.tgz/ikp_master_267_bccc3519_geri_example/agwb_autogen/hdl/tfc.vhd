--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library general_cores;
use general_cores.wishbone_pkg.all;
library work;
use work.agwb_pkg.all;
use work.tfc_pkg.all;

entity tfc is
  generic (
    g_ctrl_size : integer := c_ctrl_size;
    g_common_size : integer := c_common_size;
    g_link_size : integer := c_link_size;

    g_ver_id : std_logic_vector(31 downto 0) := c_tfc_ver_id;
    g_registered : integer := 0
  );
  port (
    slave_i : in t_wishbone_slave_in;
    slave_o : out t_wishbone_slave_out;
    common_wb_m_o : out t_wishbone_master_out;
    common_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    link_wb_m_o : out t_wishbone_master_out;
    link_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;

    ctrl_o : out  t_ctrl;

    rst_n_i : in std_logic;
    clk_sys_i : in std_logic
    );

end tfc;

architecture gener of tfc is
  signal int_ctrl_o : t_ctrl := to_ctrl(std_logic_vector(to_unsigned(0,1))); -- Hex value: 0x0


  -- Internal WB declaration
  signal int_regs_wb_m_o : t_wishbone_master_out;
  signal int_regs_wb_m_i : t_wishbone_master_in;
  signal int_addr : std_logic_vector(2-1 downto 0);
  signal wb_up_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_up_r_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_r_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_m_o : t_wishbone_master_out_array(3-1 downto 0);
  signal wb_m_i : t_wishbone_master_in_array(3-1 downto 0) := (others => c_WB_SLAVE_OUT_ERR);

  -- Constants
  constant c_address : t_wishbone_address_array(3-1  downto 0) := (0=>"00000000000000000000000000001100",1=>"00000000000000000000000000001000",2=>"00000000000000000000000000000000");
  constant c_mask : t_wishbone_address_array(3-1 downto 0) := (0=>"00000000000000000000000000001100",1=>"00000000000000000000000000001100",2=>"00000000000000000000000000001100");
begin
  
  assert g_ctrl_size <= c_ctrl_size report "g_ctrl_size must be not greater than c_ctrl_size=1" severity failure;
  assert g_common_size <= c_common_size report "g_common_size must be not greater than c_common_size=1" severity failure;
  assert g_link_size <= c_link_size report "g_link_size must be not greater than c_link_size=1" severity failure;

  wb_up_i(0) <= slave_i;
  slave_o <= wb_up_o(0);
  int_addr <= int_regs_wb_m_o.adr(2-1 downto 0);

-- Conditional adding of xwb_register   
  gr1: if g_registered = 2 generate
    grl1: for i in 0 to 1-1 generate
      xwb_register_1: entity general_cores.xwb_register
      generic map (
        g_WB_MODE => CLASSIC)
      port map (
        rst_n_i  => rst_n_i,
        clk_i    => clk_sys_i,
        slave_i  => wb_up_i(i),
        slave_o  => wb_up_o(i),
        master_i => wb_up_r_o(i),
        master_o => wb_up_r_i(i));
    end generate grl1;
  end generate gr1;

  gr2: if g_registered /= 2 generate
      wb_up_r_i <= wb_up_i;
      wb_up_o <= wb_up_r_o;
  end generate gr2;

-- Main crossbar
  xwb_crossbar_1: entity general_cores.xwb_crossbar
  generic map (
     g_num_masters => 1,
     g_num_slaves  => 3,
     g_registered  => (g_registered = 1),
     g_address     => c_address,
     g_mask        => c_mask
  )
  port map (
     clk_sys_i => clk_sys_i,
     rst_n_i   => rst_n_i,
     slave_i   => wb_up_r_i,
     slave_o   => wb_up_r_o,
     master_i  => wb_m_i,
     master_o  => wb_m_o,
     sdb_sel_o => open
  );

-- Process for register access
  process(clk_sys_i)
  begin
    if rising_edge(clk_sys_i) then
      if rst_n_i = '0' then
        -- Reset of the core
        int_regs_wb_m_i <= c_DUMMY_WB_MASTER_IN;
        int_ctrl_o <= to_ctrl(std_logic_vector(to_unsigned(0,1))); -- Hex value: 0x0

      else
        -- Clearing of trigger bits (if there are any)
        
        -- That's a single register that may be present (size=1) or not (size=0).
        -- The "for" loop works like "if".
        -- That's why we do not index the register inside the loop.
        for i in 0 to g_ctrl_size - 1 loop
           int_ctrl_o <= to_ctrl( agwb_and(to_slv(int_ctrl_o), c_ctrl_trig_clear));
        end loop;

        -- Normal operation
        int_regs_wb_m_i.rty <= '0';
        int_regs_wb_m_i.ack <= '0';
        int_regs_wb_m_i.err <= '0';

        if (int_regs_wb_m_o.cyc = '1') and (int_regs_wb_m_o.stb = '1')
            and (int_regs_wb_m_i.err = '0') and (int_regs_wb_m_i.rty = '0')
            and (int_regs_wb_m_i.ack = '0') then
          int_regs_wb_m_i.err <= '1'; -- in case of missed address
          -- Access, now we handle consecutive registers
          -- Set the error state so it is output when none register is accessed
          int_regs_wb_m_i.dat <= x"A5A5A5A5";
          int_regs_wb_m_i.ack <= '0';
          int_regs_wb_m_i.err <= '1';
          
          -- That's a single register that may be present (size=1) or not (size=0).
          -- The "for" loop works like "if".
          -- That's why we do not index the register inside the loop.
          for i in 0 to g_ctrl_size - 1 loop
            if int_addr = std_logic_vector(to_unsigned(2 + i, 2)) then
              int_regs_wb_m_i.dat <= (others => '0');
              int_regs_wb_m_i.dat(0 downto 0) <= to_slv(int_ctrl_o) and c_ctrl_trig_clear;
              if int_regs_wb_m_o.we = '1' then
                int_ctrl_o <= to_ctrl(int_regs_wb_m_o.dat(0 downto 0));
              end if;
              int_regs_wb_m_i.ack <= '1';
              int_regs_wb_m_i.err <= '0';
            end if;
          end loop; -- g_ctrl_size


          if int_addr = "00" then
             int_regs_wb_m_i.dat <= x"4ba5e55d";
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
          if int_addr = "01" then
             int_regs_wb_m_i.dat <= g_ver_id;
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
        end if;
      end if;
    end if;
  end process;
  ctrl_o <= int_ctrl_o;
  bg1: if g_common_size > 0 generate
    wb_m_i(0) <= common_wb_m_i;
    common_wb_m_o  <= wb_m_o(0);
  end generate; -- g_common_size
  bg2: if g_link_size > 0 generate
    wb_m_i(1) <= link_wb_m_i;
    link_wb_m_o  <= wb_m_o(1);
  end generate; -- g_link_size
  wb_m_i(2) <= int_regs_wb_m_i;
  int_regs_wb_m_o  <= wb_m_o(2);

end architecture;
