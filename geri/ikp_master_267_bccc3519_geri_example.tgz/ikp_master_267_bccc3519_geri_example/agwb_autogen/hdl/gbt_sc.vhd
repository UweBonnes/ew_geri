--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library general_cores;
use general_cores.wishbone_pkg.all;
library work;
use work.agwb_pkg.all;
use work.gbt_sc_pkg.all;

entity gbt_sc is
  generic (
    g_ic_size : integer := c_ic_size;
    g_ec_size : integer := c_ec_size;

    g_ver_id : std_logic_vector(31 downto 0) := c_gbt_sc_ver_id;
    g_registered : integer := 0
  );
  port (
    slave_i : in t_wishbone_slave_in;
    slave_o : out t_wishbone_slave_out;
    ic_wb_m_o : out t_wishbone_master_out;
    ic_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    ec_wb_m_o : out t_wishbone_master_out;
    ec_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;


    rst_n_i : in std_logic;
    clk_sys_i : in std_logic
    );

end gbt_sc;

architecture gener of gbt_sc is


  -- Internal WB declaration
  signal int_regs_wb_m_o : t_wishbone_master_out;
  signal int_regs_wb_m_i : t_wishbone_master_in;
  signal int_addr : std_logic_vector(1-1 downto 0);
  signal wb_up_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_up_r_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_r_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_m_o : t_wishbone_master_out_array(3-1 downto 0);
  signal wb_m_i : t_wishbone_master_in_array(3-1 downto 0) := (others => c_WB_SLAVE_OUT_ERR);

  -- Constants
  constant c_address : t_wishbone_address_array(3-1  downto 0) := (0=>"00000000000000000000000000011000",1=>"00000000000000000000000000010000",2=>"00000000000000000000000000000000");
  constant c_mask : t_wishbone_address_array(3-1 downto 0) := (0=>"00000000000000000000000000011000",1=>"00000000000000000000000000011000",2=>"00000000000000000000000000011110");
begin
  
  assert g_ic_size <= c_ic_size report "g_ic_size must be not greater than c_ic_size=1" severity failure;
  assert g_ec_size <= c_ec_size report "g_ec_size must be not greater than c_ec_size=1" severity failure;

  wb_up_i(0) <= slave_i;
  slave_o <= wb_up_o(0);
  int_addr <= int_regs_wb_m_o.adr(1-1 downto 0);

-- Conditional adding of xwb_register   
  gr1: if g_registered = 2 generate
    grl1: for i in 0 to 1-1 generate
      xwb_register_1: entity general_cores.xwb_register
      generic map (
        g_WB_MODE => CLASSIC)
      port map (
        rst_n_i  => rst_n_i,
        clk_i    => clk_sys_i,
        slave_i  => wb_up_i(i),
        slave_o  => wb_up_o(i),
        master_i => wb_up_r_o(i),
        master_o => wb_up_r_i(i));
    end generate grl1;
  end generate gr1;

  gr2: if g_registered /= 2 generate
      wb_up_r_i <= wb_up_i;
      wb_up_o <= wb_up_r_o;
  end generate gr2;

-- Main crossbar
  xwb_crossbar_1: entity general_cores.xwb_crossbar
  generic map (
     g_num_masters => 1,
     g_num_slaves  => 3,
     g_registered  => (g_registered = 1),
     g_address     => c_address,
     g_mask        => c_mask
  )
  port map (
     clk_sys_i => clk_sys_i,
     rst_n_i   => rst_n_i,
     slave_i   => wb_up_r_i,
     slave_o   => wb_up_r_o,
     master_i  => wb_m_i,
     master_o  => wb_m_o,
     sdb_sel_o => open
  );

-- Process for register access
  process(clk_sys_i)
  begin
    if rising_edge(clk_sys_i) then
      if rst_n_i = '0' then
        -- Reset of the core
        int_regs_wb_m_i <= c_DUMMY_WB_MASTER_IN;

      else
        -- Clearing of trigger bits (if there are any)

        -- Normal operation
        int_regs_wb_m_i.rty <= '0';
        int_regs_wb_m_i.ack <= '0';
        int_regs_wb_m_i.err <= '0';

        if (int_regs_wb_m_o.cyc = '1') and (int_regs_wb_m_o.stb = '1')
            and (int_regs_wb_m_i.err = '0') and (int_regs_wb_m_i.rty = '0')
            and (int_regs_wb_m_i.ack = '0') then
          int_regs_wb_m_i.err <= '1'; -- in case of missed address
          -- Access, now we handle consecutive registers
          -- Set the error state so it is output when none register is accessed
          int_regs_wb_m_i.dat <= x"A5A5A5A5";
          int_regs_wb_m_i.ack <= '0';
          int_regs_wb_m_i.err <= '1';


          if int_addr = "0" then
             int_regs_wb_m_i.dat <= x"14d5fefd";
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
          if int_addr = "1" then
             int_regs_wb_m_i.dat <= g_ver_id;
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
        end if;
      end if;
    end if;
  end process;
  bg1: if g_ic_size > 0 generate
    wb_m_i(0) <= ic_wb_m_i;
    ic_wb_m_o  <= wb_m_o(0);
  end generate; -- g_ic_size
  bg2: if g_ec_size > 0 generate
    wb_m_i(1) <= ec_wb_m_i;
    ec_wb_m_o  <= wb_m_o(1);
  end generate; -- g_ec_size
  wb_m_i(2) <= int_regs_wb_m_i;
  int_regs_wb_m_o  <= wb_m_o(2);

end architecture;
