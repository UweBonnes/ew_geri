--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library general_cores;
use general_cores.wishbone_pkg.all;
library work;
use work.agwb_pkg.all;
use work.datapath_pkg.all;

entity datapath is
  generic (
    g_hctsp_uplink_80_size : integer := c_hctsp_uplink_80_size;
    g_crob1_gbt_iface_size : integer := c_crob1_gbt_iface_size;
    g_hctsp_master_80_size : integer := c_hctsp_master_80_size;
    g_tfc_size : integer := c_tfc_size;
    g_triv_proc_size : integer := c_triv_proc_size;
    g_gbt_fpga_dummy_size : integer := c_gbt_fpga_dummy_size;

    g_ver_id : std_logic_vector(31 downto 0) := c_datapath_ver_id;
    g_registered : integer := 0
  );
  port (
    slave_i : in t_wishbone_slave_in;
    slave_o : out t_wishbone_slave_out;
    hctsp_uplink_80_wb_m_o : out t_wishbone_master_out_array( g_hctsp_uplink_80_size - 1 downto 0 );
    hctsp_uplink_80_wb_m_i : in t_wishbone_master_in_array( g_hctsp_uplink_80_size - 1 downto 0 ) := ( others => c_WB_SLAVE_OUT_ERR);
    crob1_gbt_iface_wb_m_o : out t_wishbone_master_out_array( g_crob1_gbt_iface_size - 1 downto 0 );
    crob1_gbt_iface_wb_m_i : in t_wishbone_master_in_array( g_crob1_gbt_iface_size - 1 downto 0 ) := ( others => c_WB_SLAVE_OUT_ERR);
    hctsp_master_80_wb_m_o : out t_wishbone_master_out;
    hctsp_master_80_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    tfc_wb_m_o : out t_wishbone_master_out;
    tfc_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    triv_proc_wb_m_o : out t_wishbone_master_out;
    triv_proc_wb_m_i : in t_wishbone_master_in := c_WB_SLAVE_OUT_ERR;
    gbt_fpga_dummy_wb_m_o : out t_wishbone_master_out_array( g_gbt_fpga_dummy_size - 1 downto 0 );
    gbt_fpga_dummy_wb_m_i : in t_wishbone_master_in_array( g_gbt_fpga_dummy_size - 1 downto 0 ) := ( others => c_WB_SLAVE_OUT_ERR);


    rst_n_i : in std_logic;
    clk_sys_i : in std_logic
    );

end datapath;

architecture gener of datapath is


  -- Internal WB declaration
  signal int_regs_wb_m_o : t_wishbone_master_out;
  signal int_regs_wb_m_i : t_wishbone_master_in;
  signal int_addr : std_logic_vector(1-1 downto 0);
  signal wb_up_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_up_r_o : t_wishbone_slave_out_array(1-1 downto 0);
  signal wb_up_r_i : t_wishbone_slave_in_array(1-1 downto 0);
  signal wb_m_o : t_wishbone_master_out_array(16-1 downto 0);
  signal wb_m_i : t_wishbone_master_in_array(16-1 downto 0) := (others => c_WB_SLAVE_OUT_ERR);

  -- Constants
  constant c_address : t_wishbone_address_array(16-1  downto 0) := (0=>"00000000000000000001000000000000",1=>"00000000000000000001001000000000",2=>"00000000000000000001010000000000",3=>"00000000000000000001011000000000",4=>"00000000000000000001100000000000",5=>"00000000000000000001101000000000",6=>"00000000000000000000111000000000",7=>"00000000000000000000111001000000",8=>"00000000000000000000111010000000",9=>"00000000000000000000111011000000",10=>"00000000000000000000111100000000",11=>"00000000000000000000111101000000",12=>"00000000000000000000110110000000",13=>"00000000000000000000110101110000",14=>"00000000000000000000110101101100",15=>"00000000000000000000000000000000");
  constant c_mask : t_wishbone_address_array(16-1 downto 0) := (0=>"00000000000000000001111000000000",1=>"00000000000000000001111000000000",2=>"00000000000000000001111000000000",3=>"00000000000000000001111000000000",4=>"00000000000000000001111000000000",5=>"00000000000000000001111000000000",6=>"00000000000000000001111111000000",7=>"00000000000000000001111111000000",8=>"00000000000000000001111111000000",9=>"00000000000000000001111111000000",10=>"00000000000000000001111111000000",11=>"00000000000000000001111111000000",12=>"00000000000000000001111110000000",13=>"00000000000000000001111111110000",14=>"00000000000000000001111111111100",15=>"00000000000000000001111111111110");
begin
  
  assert g_hctsp_uplink_80_size <= c_hctsp_uplink_80_size report "g_hctsp_uplink_80_size must be not greater than c_hctsp_uplink_80_size=6" severity failure;
  assert g_crob1_gbt_iface_size <= c_crob1_gbt_iface_size report "g_crob1_gbt_iface_size must be not greater than c_crob1_gbt_iface_size=6" severity failure;
  assert g_hctsp_master_80_size <= c_hctsp_master_80_size report "g_hctsp_master_80_size must be not greater than c_hctsp_master_80_size=1" severity failure;
  assert g_tfc_size <= c_tfc_size report "g_tfc_size must be not greater than c_tfc_size=1" severity failure;
  assert g_triv_proc_size <= c_triv_proc_size report "g_triv_proc_size must be not greater than c_triv_proc_size=1" severity failure;
  assert g_gbt_fpga_dummy_size <= c_gbt_fpga_dummy_size report "g_gbt_fpga_dummy_size must be not greater than c_gbt_fpga_dummy_size=0" severity failure;

  wb_up_i(0) <= slave_i;
  slave_o <= wb_up_o(0);
  int_addr <= int_regs_wb_m_o.adr(1-1 downto 0);

-- Conditional adding of xwb_register   
  gr1: if g_registered = 2 generate
    grl1: for i in 0 to 1-1 generate
      xwb_register_1: entity general_cores.xwb_register
      generic map (
        g_WB_MODE => CLASSIC)
      port map (
        rst_n_i  => rst_n_i,
        clk_i    => clk_sys_i,
        slave_i  => wb_up_i(i),
        slave_o  => wb_up_o(i),
        master_i => wb_up_r_o(i),
        master_o => wb_up_r_i(i));
    end generate grl1;
  end generate gr1;

  gr2: if g_registered /= 2 generate
      wb_up_r_i <= wb_up_i;
      wb_up_o <= wb_up_r_o;
  end generate gr2;

-- Main crossbar
  xwb_crossbar_1: entity general_cores.xwb_crossbar
  generic map (
     g_num_masters => 1,
     g_num_slaves  => 16,
     g_registered  => (g_registered = 1),
     g_address     => c_address,
     g_mask        => c_mask
  )
  port map (
     clk_sys_i => clk_sys_i,
     rst_n_i   => rst_n_i,
     slave_i   => wb_up_r_i,
     slave_o   => wb_up_r_o,
     master_i  => wb_m_i,
     master_o  => wb_m_o,
     sdb_sel_o => open
  );

-- Process for register access
  process(clk_sys_i)
  begin
    if rising_edge(clk_sys_i) then
      if rst_n_i = '0' then
        -- Reset of the core
        int_regs_wb_m_i <= c_DUMMY_WB_MASTER_IN;

      else
        -- Clearing of trigger bits (if there are any)

        -- Normal operation
        int_regs_wb_m_i.rty <= '0';
        int_regs_wb_m_i.ack <= '0';
        int_regs_wb_m_i.err <= '0';

        if (int_regs_wb_m_o.cyc = '1') and (int_regs_wb_m_o.stb = '1')
            and (int_regs_wb_m_i.err = '0') and (int_regs_wb_m_i.rty = '0')
            and (int_regs_wb_m_i.ack = '0') then
          int_regs_wb_m_i.err <= '1'; -- in case of missed address
          -- Access, now we handle consecutive registers
          -- Set the error state so it is output when none register is accessed
          int_regs_wb_m_i.dat <= x"A5A5A5A5";
          int_regs_wb_m_i.ack <= '0';
          int_regs_wb_m_i.err <= '1';


          if int_addr = "0" then
             int_regs_wb_m_i.dat <= x"02b37340";
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
          if int_addr = "1" then
             int_regs_wb_m_i.dat <= g_ver_id;
             if int_regs_wb_m_o.we = '1' then
                int_regs_wb_m_i.err <= '1';
                int_regs_wb_m_i.ack <= '0';
             else
                int_regs_wb_m_i.ack <= '1';
                int_regs_wb_m_i.err <= '0';
             end if;
          end if;
        end if;
      end if;
    end if;
  end process;
  bg1: for i in 0 to g_hctsp_uplink_80_size - 1 generate
    wb_m_i(0 + i) <= hctsp_uplink_80_wb_m_i(i);
    hctsp_uplink_80_wb_m_o(i)  <= wb_m_o(0 + i);
  end generate; -- for g_hctsp_uplink_80_size
  bg2: for i in 0 to g_crob1_gbt_iface_size - 1 generate
    wb_m_i(6 + i) <= crob1_gbt_iface_wb_m_i(i);
    crob1_gbt_iface_wb_m_o(i)  <= wb_m_o(6 + i);
  end generate; -- for g_crob1_gbt_iface_size
  bg3: if g_hctsp_master_80_size > 0 generate
    wb_m_i(12) <= hctsp_master_80_wb_m_i;
    hctsp_master_80_wb_m_o  <= wb_m_o(12);
  end generate; -- g_hctsp_master_80_size
  bg4: if g_tfc_size > 0 generate
    wb_m_i(13) <= tfc_wb_m_i;
    tfc_wb_m_o  <= wb_m_o(13);
  end generate; -- g_tfc_size
  bg5: if g_triv_proc_size > 0 generate
    wb_m_i(14) <= triv_proc_wb_m_i;
    triv_proc_wb_m_o  <= wb_m_o(14);
  end generate; -- g_triv_proc_size
  wb_m_i(15) <= int_regs_wb_m_i;
  int_regs_wb_m_o  <= wb_m_o(15);
  bg6: for i in 0 to g_gbt_fpga_dummy_size - 1 generate
    wb_m_i(16 + i) <= gbt_fpga_dummy_wb_m_i(i);
    gbt_fpga_dummy_wb_m_o(i)  <= wb_m_o(16 + i);
  end generate; -- for g_gbt_fpga_dummy_size

end architecture;
