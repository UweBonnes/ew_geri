--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package gbt_sc_pkg is

  constant C_gbt_sc_ADDR_BITS : integer := 5;

  constant c_gbt_sc_ver_id : std_logic_vector(31 downto 0) := x"487fbed9";
  constant v_gbt_sc_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"487fbed9");
  constant c_ic_size : integer := 1;
  constant c_ec_size : integer := 1;






end gbt_sc_pkg;

package body gbt_sc_pkg is

end gbt_sc_pkg;
