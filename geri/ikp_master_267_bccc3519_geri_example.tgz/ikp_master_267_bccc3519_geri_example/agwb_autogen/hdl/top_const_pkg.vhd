library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;
package top_const_pkg is
constant C_top_system_ver : std_logic_vector(31 downto 0) := x"7e204a29";
constant C_NR_CROB1 : integer := 6; -- 6
constant C_N_HCTSP_GROUPS : integer := 6; -- NR_CROB1
constant C_N_HCTSP_DOWNLINKS : integer := 6; -- 6
constant C_N_HCTSP_UPLINKS : integer := 28; -- 28
end package;
