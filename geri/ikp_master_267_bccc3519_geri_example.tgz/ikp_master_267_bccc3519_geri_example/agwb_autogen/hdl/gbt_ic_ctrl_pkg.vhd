--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package gbt_ic_ctrl_pkg is

  constant C_gbt_ic_ctrl_ADDR_BITS : integer := 3;

  constant c_gbt_ic_ctrl_ver_id : std_logic_vector(31 downto 0) := x"c5bc4775";
  constant v_gbt_ic_ctrl_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"c5bc4775");
  constant c_ctrl_trig_clear : std_logic_vector(9 downto 0) := "1111111000";
  constant c_ctrl_size : integer := 1;
  constant c_tx_rega_nbtr_size : integer := 1;
  constant c_tx_data_size : integer := 1;
  constant c_status_size : integer := 1;
  constant c_rx_mptr_nbw_size : integer := 1;
  constant c_rx_data_size : integer := 1;


  constant C_ctrl_REG_ADDR: unsigned := x"00000002";
  type t_ctrl_ic is record
    reset:std_logic_vector(0 downto 0);
    start_write:std_logic_vector(0 downto 0);
    start_read:std_logic_vector(0 downto 0);
    gbtx_addr:std_logic_vector(6 downto 0);
  end record;
  
  function to_ctrl_ic(x : std_logic_vector) return t_ctrl_ic;
  function to_slv(x : t_ctrl_ic) return std_logic_vector;
  constant C_tx_rega_nbtr_REG_ADDR: unsigned := x"00000003";
  type t_tx_rega_nbtr is record
    reg_addr:std_logic_vector(15 downto 0);
    bytes_to_read:std_logic_vector(15 downto 0);
  end record;
  
  function to_tx_rega_nbtr(x : std_logic_vector) return t_tx_rega_nbtr;
  function to_slv(x : t_tx_rega_nbtr) return std_logic_vector;
  constant C_tx_data_REG_ADDR: unsigned := x"00000004";
  subtype t_ic_tx_data is std_logic_vector(7 downto 0);
  constant C_status_REG_ADDR: unsigned := x"00000005";
  type t_status_ic is record
    tx_ready:std_logic_vector(0 downto 0);
    rx_empty:std_logic_vector(0 downto 0);
    gbtx_addr:std_logic_vector(6 downto 0);
  end record;
  
  function to_status_ic(x : std_logic_vector) return t_status_ic;
  function to_slv(x : t_status_ic) return std_logic_vector;
  constant C_rx_mptr_nbw_REG_ADDR: unsigned := x"00000006";
  type t_rx_mptr_nbw is record
    mem_ptr:std_logic_vector(15 downto 0);
    words_read:std_logic_vector(15 downto 0);
  end record;
  
  function to_rx_mptr_nbw(x : std_logic_vector) return t_rx_mptr_nbw;
  function to_slv(x : t_rx_mptr_nbw) return std_logic_vector;
  constant C_rx_data_REG_ADDR: unsigned := x"00000007";
  subtype t_ic_rx_data is std_logic_vector(7 downto 0);




end gbt_ic_ctrl_pkg;

package body gbt_ic_ctrl_pkg is
  function to_ctrl_ic(x : std_logic_vector) return t_ctrl_ic is
    variable res : t_ctrl_ic;
  begin
    res.reset := std_logic_vector(x(0 downto 0));
    res.start_write := std_logic_vector(x(1 downto 1));
    res.start_read := std_logic_vector(x(2 downto 2));
    res.gbtx_addr := std_logic_vector(x(9 downto 3));
    return res;
  end function;
  
  function to_slv(x : t_ctrl_ic) return std_logic_vector is
    variable res : std_logic_vector(9 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.reset);
    res(1 downto 1) := std_logic_vector(x.start_write);
    res(2 downto 2) := std_logic_vector(x.start_read);
    res(9 downto 3) := std_logic_vector(x.gbtx_addr);
    return res;
  end function;
  
  function to_tx_rega_nbtr(x : std_logic_vector) return t_tx_rega_nbtr is
    variable res : t_tx_rega_nbtr;
  begin
    res.reg_addr := std_logic_vector(x(15 downto 0));
    res.bytes_to_read := std_logic_vector(x(31 downto 16));
    return res;
  end function;
  
  function to_slv(x : t_tx_rega_nbtr) return std_logic_vector is
    variable res : std_logic_vector(31 downto 0);
  begin
    res(15 downto 0) := std_logic_vector(x.reg_addr);
    res(31 downto 16) := std_logic_vector(x.bytes_to_read);
    return res;
  end function;
  
  function to_status_ic(x : std_logic_vector) return t_status_ic is
    variable res : t_status_ic;
  begin
    res.tx_ready := std_logic_vector(x(0 downto 0));
    res.rx_empty := std_logic_vector(x(1 downto 1));
    res.gbtx_addr := std_logic_vector(x(8 downto 2));
    return res;
  end function;
  
  function to_slv(x : t_status_ic) return std_logic_vector is
    variable res : std_logic_vector(8 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.tx_ready);
    res(1 downto 1) := std_logic_vector(x.rx_empty);
    res(8 downto 2) := std_logic_vector(x.gbtx_addr);
    return res;
  end function;
  
  function to_rx_mptr_nbw(x : std_logic_vector) return t_rx_mptr_nbw is
    variable res : t_rx_mptr_nbw;
  begin
    res.mem_ptr := std_logic_vector(x(15 downto 0));
    res.words_read := std_logic_vector(x(31 downto 16));
    return res;
  end function;
  
  function to_slv(x : t_rx_mptr_nbw) return std_logic_vector is
    variable res : std_logic_vector(31 downto 0);
  begin
    res(15 downto 0) := std_logic_vector(x.mem_ptr);
    res(31 downto 16) := std_logic_vector(x.words_read);
    return res;
  end function;
  

end gbt_ic_ctrl_pkg;
