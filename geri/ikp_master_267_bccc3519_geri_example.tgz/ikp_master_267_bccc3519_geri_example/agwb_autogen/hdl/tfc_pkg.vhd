--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package tfc_pkg is

  constant C_tfc_ADDR_BITS : integer := 4;

  constant c_tfc_ver_id : std_logic_vector(31 downto 0) := x"a816dfb8";
  constant v_tfc_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"a816dfb8");
  constant c_ctrl_trig_clear : std_logic_vector(0 downto 0) := "0";
  constant c_ctrl_size : integer := 1;
  constant c_common_size : integer := 1;
  constant c_link_size : integer := 1;


  constant C_ctrl_REG_ADDR: unsigned := x"00000002";
  type t_ctrl is record
    sync_time:std_logic_vector(0 downto 0);
  end record;
  
  function to_ctrl(x : std_logic_vector) return t_ctrl;
  function to_slv(x : t_ctrl) return std_logic_vector;




end tfc_pkg;

package body tfc_pkg is
  function to_ctrl(x : std_logic_vector) return t_ctrl is
    variable res : t_ctrl;
  begin
    res.sync_time := std_logic_vector(x(0 downto 0));
    return res;
  end function;
  
  function to_slv(x : t_ctrl) return std_logic_vector is
    variable res : std_logic_vector(0 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.sync_time);
    return res;
  end function;
  

end tfc_pkg;
