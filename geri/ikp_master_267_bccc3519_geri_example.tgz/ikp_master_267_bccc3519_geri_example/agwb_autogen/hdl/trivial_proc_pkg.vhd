--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package trivial_proc_pkg is

  constant C_trivial_proc_ADDR_BITS : integer := 2;

  constant c_trivial_proc_ver_id : std_logic_vector(31 downto 0) := x"642d0463";
  constant v_trivial_proc_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"642d0463");
  constant c_ctrl_size : integer := 1;
  constant c_pkt_duration_size : integer := 1;


  constant C_ctrl_REG_ADDR: unsigned := x"00000002";
  type t_ctrl is record
    reset:std_logic_vector(0 downto 0);
    run:std_logic_vector(0 downto 0);
    crob_disable:std_logic_vector(7 downto 0);
  end record;
  
  function to_ctrl(x : std_logic_vector) return t_ctrl;
  function to_slv(x : t_ctrl) return std_logic_vector;
  constant C_pkt_duration_REG_ADDR: unsigned := x"00000003";
  subtype t_pkt_duration is unsigned(31 downto 0);




end trivial_proc_pkg;

package body trivial_proc_pkg is
  function to_ctrl(x : std_logic_vector) return t_ctrl is
    variable res : t_ctrl;
  begin
    res.reset := std_logic_vector(x(0 downto 0));
    res.run := std_logic_vector(x(1 downto 1));
    res.crob_disable := std_logic_vector(x(9 downto 2));
    return res;
  end function;
  
  function to_slv(x : t_ctrl) return std_logic_vector is
    variable res : std_logic_vector(9 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.reset);
    res(1 downto 1) := std_logic_vector(x.run);
    res(9 downto 2) := std_logic_vector(x.crob_disable);
    return res;
  end function;
  

end trivial_proc_pkg;
