--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package datapath_pkg is

  constant C_datapath_ADDR_BITS : integer := 13;

  constant c_datapath_ver_id : std_logic_vector(31 downto 0) := x"487e5848";
  constant v_datapath_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"487e5848");
  constant c_hctsp_uplink_80_size : integer := 6;
  constant c_crob1_gbt_iface_size : integer := 6;
  constant c_hctsp_master_80_size : integer := 1;
  constant c_tfc_size : integer := 1;
  constant c_triv_proc_size : integer := 1;
  constant c_gbt_fpga_dummy_size : integer := 0;






end datapath_pkg;

package body datapath_pkg is

end datapath_pkg;
