--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package gbt_fpga_link_pkg is

  constant C_gbt_fpga_link_ADDR_BITS : integer := 2;

  constant c_gbt_fpga_link_ver_id : std_logic_vector(31 downto 0) := x"c41b9f6b";
  constant v_gbt_fpga_link_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"c41b9f6b");
  constant c_status_size : integer := 1;
  constant c_status_with_clear_size : integer := 1;


  constant C_status_REG_ADDR: unsigned := x"00000002";
  type t_status is record
    link_ready:std_logic_vector(0 downto 0);
    rx_ready:std_logic_vector(0 downto 0);
    rx_headerflag:std_logic_vector(0 downto 0);
    rx_header_locked:std_logic_vector(0 downto 0);
    tx_ready:std_logic_vector(0 downto 0);
    tx_phaligned:std_logic_vector(0 downto 0);
    tx_phaligned_val:std_logic_vector(0 downto 0);
    rx_bufferbypas_error:std_logic_vector(0 downto 0);
    tx_bufferbypas_error:std_logic_vector(0 downto 0);
    rx_ic_inactive:std_logic_vector(0 downto 0);
  end record;
  
  function to_status(x : std_logic_vector) return t_status;
  function to_slv(x : t_status) return std_logic_vector;
  constant C_status_with_clear_REG_ADDR: unsigned := x"00000003";
  type t_status_with_clear is record
    rx_error_cnt:std_logic_vector(7 downto 0);
    rx_readyloss_cnt:std_logic_vector(7 downto 0);
    rx_pattcheck_errcnt:std_logic_vector(15 downto 0);
  end record;
  
  function to_status_with_clear(x : std_logic_vector) return t_status_with_clear;
  function to_slv(x : t_status_with_clear) return std_logic_vector;




end gbt_fpga_link_pkg;

package body gbt_fpga_link_pkg is
  function to_status(x : std_logic_vector) return t_status is
    variable res : t_status;
  begin
    res.link_ready := std_logic_vector(x(0 downto 0));
    res.rx_ready := std_logic_vector(x(1 downto 1));
    res.rx_headerflag := std_logic_vector(x(2 downto 2));
    res.rx_header_locked := std_logic_vector(x(3 downto 3));
    res.tx_ready := std_logic_vector(x(4 downto 4));
    res.tx_phaligned := std_logic_vector(x(5 downto 5));
    res.tx_phaligned_val := std_logic_vector(x(6 downto 6));
    res.rx_bufferbypas_error := std_logic_vector(x(7 downto 7));
    res.tx_bufferbypas_error := std_logic_vector(x(8 downto 8));
    res.rx_ic_inactive := std_logic_vector(x(9 downto 9));
    return res;
  end function;
  
  function to_slv(x : t_status) return std_logic_vector is
    variable res : std_logic_vector(9 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.link_ready);
    res(1 downto 1) := std_logic_vector(x.rx_ready);
    res(2 downto 2) := std_logic_vector(x.rx_headerflag);
    res(3 downto 3) := std_logic_vector(x.rx_header_locked);
    res(4 downto 4) := std_logic_vector(x.tx_ready);
    res(5 downto 5) := std_logic_vector(x.tx_phaligned);
    res(6 downto 6) := std_logic_vector(x.tx_phaligned_val);
    res(7 downto 7) := std_logic_vector(x.rx_bufferbypas_error);
    res(8 downto 8) := std_logic_vector(x.tx_bufferbypas_error);
    res(9 downto 9) := std_logic_vector(x.rx_ic_inactive);
    return res;
  end function;
  
  function to_status_with_clear(x : std_logic_vector) return t_status_with_clear is
    variable res : t_status_with_clear;
  begin
    res.rx_error_cnt := std_logic_vector(x(7 downto 0));
    res.rx_readyloss_cnt := std_logic_vector(x(15 downto 8));
    res.rx_pattcheck_errcnt := std_logic_vector(x(31 downto 16));
    return res;
  end function;
  
  function to_slv(x : t_status_with_clear) return std_logic_vector is
    variable res : std_logic_vector(31 downto 0);
  begin
    res(7 downto 0) := std_logic_vector(x.rx_error_cnt);
    res(15 downto 8) := std_logic_vector(x.rx_readyloss_cnt);
    res(31 downto 16) := std_logic_vector(x.rx_pattcheck_errcnt);
    return res;
  end function;
  

end gbt_fpga_link_pkg;
