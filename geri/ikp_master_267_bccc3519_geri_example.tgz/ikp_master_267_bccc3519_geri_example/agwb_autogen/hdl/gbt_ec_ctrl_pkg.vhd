--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package gbt_ec_ctrl_pkg is

  constant C_gbt_ec_ctrl_ADDR_BITS : integer := 3;

  constant c_gbt_ec_ctrl_ver_id : std_logic_vector(31 downto 0) := x"43e97d78";
  constant v_gbt_ec_ctrl_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"43e97d78");
  constant c_ctrl_trig_clear : std_logic_vector(3 downto 0) := "1000";
  constant c_ctrl_size : integer := 1;
  constant c_tx_cmd_size : integer := 1;
  constant c_tx_data_size : integer := 1;
  constant c_status_size : integer := 1;
  constant c_status2_size : integer := 1;
  constant c_rx_data_size : integer := 1;


  constant C_ctrl_REG_ADDR: unsigned := x"00000002";
  type t_ctrl_ec is record
    start_reset:std_logic_vector(0 downto 0);
    start_connect:std_logic_vector(0 downto 0);
    start_cmd:std_logic_vector(0 downto 0);
    inject_crc_error:std_logic_vector(0 downto 0);
  end record;
  
  function to_ctrl_ec(x : std_logic_vector) return t_ctrl_ec;
  function to_slv(x : t_ctrl_ec) return std_logic_vector;
  constant C_tx_cmd_REG_ADDR: unsigned := x"00000003";
  type t_tx_cmd is record
    command:std_logic_vector(7 downto 0);
    addr:std_logic_vector(7 downto 0);
    chan:std_logic_vector(7 downto 0);
    trans_id:std_logic_vector(7 downto 0);
  end record;
  
  function to_tx_cmd(x : std_logic_vector) return t_tx_cmd;
  function to_slv(x : t_tx_cmd) return std_logic_vector;
  constant C_tx_data_REG_ADDR: unsigned := x"00000004";
  subtype t_ec_tx_data is std_logic_vector(31 downto 0);
  constant C_status_REG_ADDR: unsigned := x"00000005";
  type t_status_ec is record
    received:std_logic_vector(0 downto 0);
    len:std_logic_vector(7 downto 0);
    error:std_logic_vector(7 downto 0);
  end record;
  
  function to_status_ec(x : std_logic_vector) return t_status_ec;
  function to_slv(x : t_status_ec) return std_logic_vector;
  constant C_status2_REG_ADDR: unsigned := x"00000006";
  type t_status2_ec is record
    control:std_logic_vector(7 downto 0);
    addr:std_logic_vector(7 downto 0);
    chan:std_logic_vector(7 downto 0);
    trans_id:std_logic_vector(7 downto 0);
  end record;
  
  function to_status2_ec(x : std_logic_vector) return t_status2_ec;
  function to_slv(x : t_status2_ec) return std_logic_vector;
  constant C_rx_data_REG_ADDR: unsigned := x"00000007";
  subtype t_ec_rx_data is std_logic_vector(31 downto 0);




end gbt_ec_ctrl_pkg;

package body gbt_ec_ctrl_pkg is
  function to_ctrl_ec(x : std_logic_vector) return t_ctrl_ec is
    variable res : t_ctrl_ec;
  begin
    res.start_reset := std_logic_vector(x(0 downto 0));
    res.start_connect := std_logic_vector(x(1 downto 1));
    res.start_cmd := std_logic_vector(x(2 downto 2));
    res.inject_crc_error := std_logic_vector(x(3 downto 3));
    return res;
  end function;
  
  function to_slv(x : t_ctrl_ec) return std_logic_vector is
    variable res : std_logic_vector(3 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.start_reset);
    res(1 downto 1) := std_logic_vector(x.start_connect);
    res(2 downto 2) := std_logic_vector(x.start_cmd);
    res(3 downto 3) := std_logic_vector(x.inject_crc_error);
    return res;
  end function;
  
  function to_tx_cmd(x : std_logic_vector) return t_tx_cmd is
    variable res : t_tx_cmd;
  begin
    res.command := std_logic_vector(x(7 downto 0));
    res.addr := std_logic_vector(x(15 downto 8));
    res.chan := std_logic_vector(x(23 downto 16));
    res.trans_id := std_logic_vector(x(31 downto 24));
    return res;
  end function;
  
  function to_slv(x : t_tx_cmd) return std_logic_vector is
    variable res : std_logic_vector(31 downto 0);
  begin
    res(7 downto 0) := std_logic_vector(x.command);
    res(15 downto 8) := std_logic_vector(x.addr);
    res(23 downto 16) := std_logic_vector(x.chan);
    res(31 downto 24) := std_logic_vector(x.trans_id);
    return res;
  end function;
  
  function to_status_ec(x : std_logic_vector) return t_status_ec is
    variable res : t_status_ec;
  begin
    res.received := std_logic_vector(x(0 downto 0));
    res.len := std_logic_vector(x(8 downto 1));
    res.error := std_logic_vector(x(16 downto 9));
    return res;
  end function;
  
  function to_slv(x : t_status_ec) return std_logic_vector is
    variable res : std_logic_vector(16 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.received);
    res(8 downto 1) := std_logic_vector(x.len);
    res(16 downto 9) := std_logic_vector(x.error);
    return res;
  end function;
  
  function to_status2_ec(x : std_logic_vector) return t_status2_ec is
    variable res : t_status2_ec;
  begin
    res.control := std_logic_vector(x(7 downto 0));
    res.addr := std_logic_vector(x(15 downto 8));
    res.chan := std_logic_vector(x(23 downto 16));
    res.trans_id := std_logic_vector(x(31 downto 24));
    return res;
  end function;
  
  function to_slv(x : t_status2_ec) return std_logic_vector is
    variable res : std_logic_vector(31 downto 0);
  begin
    res(7 downto 0) := std_logic_vector(x.control);
    res(15 downto 8) := std_logic_vector(x.addr);
    res(23 downto 16) := std_logic_vector(x.chan);
    res(31 downto 24) := std_logic_vector(x.trans_id);
    return res;
  end function;
  

end gbt_ec_ctrl_pkg;
