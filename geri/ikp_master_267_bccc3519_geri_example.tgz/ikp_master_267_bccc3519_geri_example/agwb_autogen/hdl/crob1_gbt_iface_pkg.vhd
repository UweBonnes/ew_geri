--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package crob1_gbt_iface_pkg is

  constant C_crob1_gbt_iface_ADDR_BITS : integer := 6;

  constant c_crob1_gbt_iface_ver_id : std_logic_vector(31 downto 0) := x"22888b26";
  constant v_crob1_gbt_iface_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"22888b26");
  constant c_gbt_sc_size : integer := 1;
  constant c_common_size : integer := 1;
  constant c_link_size : integer := 1;






end crob1_gbt_iface_pkg;

package body crob1_gbt_iface_pkg is

end crob1_gbt_iface_pkg;
