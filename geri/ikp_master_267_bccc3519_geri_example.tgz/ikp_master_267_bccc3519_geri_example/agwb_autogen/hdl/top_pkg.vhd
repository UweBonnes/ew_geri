--- This file has been automatically generated
--- by the agwb (https://github.com/wzab/agwb).
--- Please don't edit it manually, unless you really have to do it
library ieee;

use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library general_cores;
use general_cores.wishbone_pkg.all;

library work;
use work.agwb_pkg.all;

package top_pkg is

  constant C_top_ADDR_BITS : integer := 14;

  constant c_top_ver_id : std_logic_vector(31 downto 0) := x"fcb5ed56";
  constant v_top_ver_id : t_ver_id_variants(0 downto 0) := (0 => x"fcb5ed56");
  constant c_clk_ref40_freq_size : integer := 1;
  constant c_clk_ref120_freq_size : integer := 1;
  constant c_clk_jcosc_freq_size : integer := 1;
  constant c_clk_recovered_freq_size : integer := 1;
  constant c_clk_recovered_vs_ref_freq_size : integer := 1;
  constant c_testreg_size : integer := 1;
  constant c_geritop_ctrl_size : integer := 1;
  constant c_datapath_size : integer := 1;
  constant c_i2c_master_size : integer := 1;
  constant c_spi_master_size : integer := 1;
  constant c_mmcm_controller_size : integer := 1;


  constant C_clk_ref40_freq_REG_ADDR: unsigned := x"00000002";
  subtype t_clk_ref40_freq is std_logic_vector(31 downto 0);
  constant C_clk_ref120_freq_REG_ADDR: unsigned := x"00000003";
  subtype t_clk_ref120_freq is std_logic_vector(31 downto 0);
  constant C_clk_jcosc_freq_REG_ADDR: unsigned := x"00000004";
  subtype t_clk_jcosc_freq is std_logic_vector(31 downto 0);
  constant C_clk_recovered_freq_REG_ADDR: unsigned := x"00000005";
  subtype t_clk_recovered_freq is std_logic_vector(31 downto 0);
  constant C_clk_recovered_vs_ref_freq_REG_ADDR: unsigned := x"00000006";
  subtype t_clk_recovered_vs_ref_freq is std_logic_vector(31 downto 0);
  constant C_testreg_REG_ADDR: unsigned := x"00000007";
  subtype t_testreg is std_logic_vector(31 downto 0);
  constant C_geritop_ctrl_REG_ADDR: unsigned := x"00000008";
  type t_geritop_ctrl is record
    i2cmaster_rst:std_logic_vector(0 downto 0);
    spimaster_rst:std_logic_vector(0 downto 0);
    jc_reset:std_logic_vector(0 downto 0);
    jc_sync:std_logic_vector(0 downto 0);
    clk_rec_oe:std_logic_vector(7 downto 0);
    refclk_av:std_logic_vector(0 downto 0);
  end record;
  
  function to_geritop_ctrl(x : std_logic_vector) return t_geritop_ctrl;
  function to_slv(x : t_geritop_ctrl) return std_logic_vector;




end top_pkg;

package body top_pkg is
  function to_geritop_ctrl(x : std_logic_vector) return t_geritop_ctrl is
    variable res : t_geritop_ctrl;
  begin
    res.i2cmaster_rst := std_logic_vector(x(0 downto 0));
    res.spimaster_rst := std_logic_vector(x(1 downto 1));
    res.jc_reset := std_logic_vector(x(2 downto 2));
    res.jc_sync := std_logic_vector(x(3 downto 3));
    res.clk_rec_oe := std_logic_vector(x(11 downto 4));
    res.refclk_av := std_logic_vector(x(12 downto 12));
    return res;
  end function;
  
  function to_slv(x : t_geritop_ctrl) return std_logic_vector is
    variable res : std_logic_vector(12 downto 0);
  begin
    res(0 downto 0) := std_logic_vector(x.i2cmaster_rst);
    res(1 downto 1) := std_logic_vector(x.spimaster_rst);
    res(2 downto 2) := std_logic_vector(x.jc_reset);
    res(3 downto 3) := std_logic_vector(x.jc_sync);
    res(11 downto 4) := std_logic_vector(x.clk_rec_oe);
    res(12 downto 12) := std_logic_vector(x.refclk_av);
    return res;
  end function;
  

end top_pkg;
