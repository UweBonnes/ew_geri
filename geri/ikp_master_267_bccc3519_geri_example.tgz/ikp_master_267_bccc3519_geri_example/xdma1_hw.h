// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x0000 : reserved
// 0x0004 : reserved
// 0x0008 : reserved
// 0x000c : reserved
// 0x0010 : Data signal of descs
//          bit 31~0 - descs[31:0] (Read/Write)
// 0x0014 : Data signal of descs
//          bit 31~0 - descs[63:32] (Read/Write)
// 0x0018 : reserved
// 0x001c : Data signal of nof_bufs
//          bit 31~0 - nof_bufs[31:0] (Read/Write)
// 0x0020 : reserved
// 0x4000 ~
// 0x7fff : Memory 'bufs' (2048 * 64b)
//          Word 2n   : bit [31:0] - bufs[n][31: 0]
//          Word 2n+1 : bit [31:0] - bufs[n][63:32]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDMA1_CONTROL_ADDR_DESCS_DATA    0x0010
#define XDMA1_CONTROL_BITS_DESCS_DATA    64
#define XDMA1_CONTROL_ADDR_NOF_BUFS_DATA 0x001c
#define XDMA1_CONTROL_BITS_NOF_BUFS_DATA 32
#define XDMA1_CONTROL_ADDR_BUFS_BASE     0x4000
#define XDMA1_CONTROL_ADDR_BUFS_HIGH     0x7fff
#define XDMA1_CONTROL_WIDTH_BUFS         64
#define XDMA1_CONTROL_DEPTH_BUFS         2048

